<meta charset="utf-8">

<?php
include ("mysql.php");


if (isset($_GET["uuid"])){
	$mysqli = cn2db($dbServer, $dbUserName, $dbPassword, $dbDatabase);
	$sql= "SELECT `startTime` FROM `order` WHERE `uuid` = '".$_GET["uuid"]."'";
	//echo $sql;
	$result=mysqli_query($mysqli,$sql);
	$startRecord='';
	$a=1;
	while ($row = mysqli_fetch_row($result)) {
		if($a==1){
			$startRecord=$startRecord.$row[0];
			$a+=1;
		}else{
			$startRecord=$startRecord.",".$row[0];
		}		
	}		
	echo $startRecord;
	$mysqli -> close();
}
?>