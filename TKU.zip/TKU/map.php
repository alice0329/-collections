<html>
<head>
<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDxG3c1KLC9qOPt_tFddwyqlx90Qz4reAk&signed_in=true&callback=initMap" async defer></script>
<script>
var routes = [];
var points = [];
function initMap() {
 var map = new google.maps.Map(document.getElementById('map'), {
  zoom: 15,
  center: {lat: 25.174708, lng: 121.450392}
 });

 var prev = null;
 for (var i=0, cnt=data['results'].length; i<cnt ; ++i) {
  var point = new google.maps.LatLng(data['results'][i]['location'].lat,data['results'][i]['location'].lng);
  points.push({
   location: point,
   stopover: false, // 是否顯示
  });

  // add marker
  if (0) {
   var marker = new google.maps.Marker({
    map: map,
    position: point,
   });
  }
  if (prev) {
   // use multiple routes
   routes.push({
    origin: prev,
    destination: point,
    travelMode: google.maps.TravelMode.DRIVING
   });
  }
  prev = point;
 }

 var directionsService = new google.maps.DirectionsService;
 // multiple routes
 // https://developers.google.com/maps/documentation/javascript/directions
 if (0) {
  for (var i=0, cnt=routes.length ; i<cnt ; ++i) {
   console.log(i);
   directionsService.route(routes[i], function(result, status) {
    if (status == google.maps.DirectionsStatus.OK) {
     var directionsDisplay = new google.maps.DirectionsRenderer({
      suppressMarkers: true
     });
     directionsDisplay.setMap(map);
     directionsDisplay.setDirections(result);
    }
   } );
  }
 }

 // use multiple stops
 // https://developers.google.com/maps/documentation/javascript/directions#Waypoints
 var max_steps = 36;
 for (var i=0, cnt=points.length; i < cnt ; i += max_steps) {
  var stops = []; // max should be 8
  var next_stop = Math.floor(max_steps / (8-2) );
  for (var j=i+next_stop ; j<(max_steps - next_stop) && j < (cnt - 1) ; j += next_stop)  // 去頭去尾, 頭擺在 origin
   stops.push(points[j]);
  var request = {
   origin: points[i].location,
   destination: i+(max_steps - 1) < cnt ? points[i+max_steps-1].location : points[cnt-1].location,
   waypoints: stops,
   travelMode: google.maps.TravelMode.DRIVING,
  };
  directionsService.route(request, function(result, status) {
   if (status == google.maps.DirectionsStatus.OK) {
    var directionsDisplay = new google.maps.DirectionsRenderer({
     suppressMarkers: true // 單純畫路線，不要顯示 marker
    });
    directionsDisplay.setMap(map);
    directionsDisplay.setDirections(result);
   } else {
    console.log( status ); // OVER_QUERY_LIMIT, MAX_WAYPOINTS_EXCEEDED
   }
  } );
 }
}

var data =
{
 "results": [{
"location" : {"lng" : 121.450392,"lat" : 25.174708
}},{"location" : {"lng" : 121.450392,"lat" : 25.174708
}},{"location" : {"lng" : 121.450392,"lat" : 25.174708
}},{"location" : {"lng" : 121.450392,"lat" : 25.174708
}},{"location" : {"lng" : 121.450392,"lat" : 25.174708
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450281,"lat" : 25.175449
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450102,"lat" : 25.175514
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.450033,"lat" : 25.175061
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449734,"lat" : 25.174881
}},{"location" : {"lng" : 121.449535,"lat" : 25.174943
}},{"location" : {"lng" : 121.449535,"lat" : 25.174943
}},{"location" : {"lng" : 121.449535,"lat" : 25.174943
}},{"location" : {"lng" : 121.449535,"lat" : 25.174943
}},{"location" : {"lng" : 121.4493322,"lat" : 25.17458831
}},{"location" : {"lng" : 121.4493298,"lat" : 25.17457108
}},{"location" : {"lng" : 121.4493271,"lat" : 25.17459483
}},{"location" : {"lng" : 121.4492737,"lat" : 25.17461806
}},{"location" : {"lng" : 121.4492465,"lat" : 25.17459513
}},{"location" : {"lng" : 121.4492141,"lat" : 25.17459717
}},{"location" : {"lng" : 121.4491769,"lat" : 25.17461308
}},{"location" : {"lng" : 121.4491546,"lat" : 25.17464239
}},{"location" : {"lng" : 121.4491223,"lat" : 25.17464102
}},{"location" : {"lng" : 121.4490924,"lat" : 25.17460419
}},{"location" : {"lng" : 121.4490686,"lat" : 25.17456999
}},{"location" : {"lng" : 121.4490388,"lat" : 25.17453848
}},{"location" : {"lng" : 121.4490203,"lat" : 25.17448038
}},{"location" : {"lng" : 121.4490248,"lat" : 25.17450367
}},{"location" : {"lng" : 121.449015,"lat" : 25.17448961
}},{"location" : {"lng" : 121.4490012,"lat" : 25.17446879
}},{"location" : {"lng" : 121.4489828,"lat" : 25.17445729
}},{"location" : {"lng" : 121.4489192,"lat" : 25.17446109
}},{"location" : {"lng" : 121.4489569,"lat" : 25.17445815
}},{"location" : {"lng" : 121.4488452,"lat" : 25.17447468
}},{"location" : {"lng" : 121.448816,"lat" : 25.17446131
}},{"location" : {"lng" : 121.4487829,"lat" : 25.17444888
}},{"location" : {"lng" : 121.448751,"lat" : 25.17443833
}},{"location" : {"lng" : 121.4487238,"lat" : 25.1744279
}},{"location" : {"lng" : 121.4487103,"lat" : 25.17442636
}},{"location" : {"lng" : 121.4486828,"lat" : 25.17440937
}},{"location" : {"lng" : 121.4486621,"lat" : 25.17439073
}},{"location" : {"lng" : 121.4486031,"lat" : 25.17437101
}},{"location" : {"lng" : 121.4485764,"lat" : 25.17435243
}},{"location" : {"lng" : 121.4485473,"lat" : 25.17433917
}},{"location" : {"lng" : 121.4485129,"lat" : 25.17433224
}},{"location" : {"lng" : 121.4484905,"lat" : 25.17432474
}},{"location" : {"lng" : 121.4484516,"lat" : 25.17429876
}},{"location" : {"lng" : 121.4484269,"lat" : 25.17429725
}},{"location" : {"lng" : 121.4484005,"lat" : 25.17429118
}},{"location" : {"lng" : 121.4483688,"lat" : 25.17424095
}},{"location" : {"lng" : 121.4483762,"lat" : 25.1742741
}},{"location" : {"lng" : 121.4483513,"lat" : 25.17421684
}},{"location" : {"lng" : 121.4483212,"lat" : 25.17421289
}},{"location" : {"lng" : 121.4482701,"lat" : 25.17420727
}},{"location" : {"lng" : 121.4482376,"lat" : 25.17419866
}},{"location" : {"lng" : 121.4481885,"lat" : 25.17419329
}},{"location" : {"lng" : 121.4481402,"lat" : 25.17419251
}},{"location" : {"lng" : 121.448112,"lat" : 25.17421367
}},{"location" : {"lng" : 121.4480992,"lat" : 25.17419995
}},{"location" : {"lng" : 121.4480556,"lat" : 25.17415598
}},{"location" : {"lng" : 121.4480383,"lat" : 25.17413299
}},{"location" : {"lng" : 121.4480042,"lat" : 25.17411541
}},{"location" : {"lng" : 121.4480024,"lat" : 25.17409758
}},{"location" : {"lng" : 121.4480451,"lat" : 25.17405581
}},{"location" : {"lng" : 121.4480429,"lat" : 25.17406678
}},{"location" : {"lng" : 121.4480227,"lat" : 25.17407305
}},{"location" : {"lng" : 121.4479908,"lat" : 25.17405985
}},{"location" : {"lng" : 121.4479615,"lat" : 25.17405764
}},{"location" : {"lng" : 121.4479209,"lat" : 25.17404454
}},{"location" : {"lng" : 121.4478754,"lat" : 25.17405532
}},{"location" : {"lng" : 121.4478784,"lat" : 25.17403633
}},{"location" : {"lng" : 121.4478931,"lat" : 25.17406781
}},{"location" : {"lng" : 121.4478728,"lat" : 25.1740682
}},{"location" : {"lng" : 121.4478517,"lat" : 25.17405984
}},{"location" : {"lng" : 121.447827,"lat" : 25.17404582
}},{"location" : {"lng" : 121.4478092,"lat" : 25.17403347
}},{"location" : {"lng" : 121.447796,"lat" : 25.17400388
}},{"location" : {"lng" : 121.4477679,"lat" : 25.17392215
}},{"location" : {"lng" : 121.4477562,"lat" : 25.17388778
}},{"location" : {"lng" : 121.4477754,"lat" : 25.17382912
}},{"location" : {"lng" : 121.4477708,"lat" : 25.17380542
}},{"location" : {"lng" : 121.4477518,"lat" : 25.17378901
}},{"location" : {"lng" : 121.4477291,"lat" : 25.17377223
}},{"location" : {"lng" : 121.4476973,"lat" : 25.17376826
}},{"location" : {"lng" : 121.4476281,"lat" : 25.17377676
}},{"location" : {"lng" : 121.4476025,"lat" : 25.17378392
}},{"location" : {"lng" : 121.4475745,"lat" : 25.17381427
}}]
};
</script>
</head>
<body>
 <div id="map" style="width:100%; height:100%;"></div>
</body>
</html>