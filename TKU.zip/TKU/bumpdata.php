<?php
// 設定文件utf-8編碼
header("Content-Type:text/html; charset=utf-8");
header("Access-Control-Allow-Origin: *");
// 加入DB共用常變數
@$id = $_GET["uuid"];
@$starttime = $_GET["starttime"];

if(isset($_GET["uuid"]) && $_GET["uuid"]!="" && isset($_GET["starttime"]) &&$_GET["starttime"]!=""){
	$mysqli = new mysqli('localhost', 'root', '', 'bumpdb');
	$sql = "SELECT `cValue`,`wValue` FROM `compute` WHERE `id`='".$_GET['uuid']."' and `starttime` ='".$_GET['starttime']."'";
	//echo $sql;
	$mysqli -> set_charset("utf8");
	$result = $mysqli -> query($sql);
	$outdata = "";
	$a=1;
	while ($row = mysqli_fetch_row($result)) {
		if($a==1){
			$outdata =$outdata . $row[0].','.$row[1];
			$a+=1;
		}else{
			$outdata =$outdata . ','.$row[0].','.$row[1];
		}
									
	}
	//$outdata =  rtrim($outdata,',');
	echo $outdata;
}
else{
	echo "error";
}
 ?>