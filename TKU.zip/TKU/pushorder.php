<meta charset="utf-8">

<?php
include ("mysql.php");
date_default_timezone_set('Asia/Taipei');
$datetime= date("Y/m/d H:i:s");

if (isset($_GET["uuid"])){
	$mysqli = cn2db($dbServer, $dbUserName, $dbPassword, $dbDatabase);
	$sql= "INSERT INTO `order` (`no`,`uuid`,`startTime`) VALUES ('',".$_GET["uuid"].",'".$_GET["startTime"]."')";
	
	if (!mysqli_query($mysqli,$sql)) {
		echo "MySQL Error: " . mysqli_error($mysqli);
	} else {
		echo "Success1";
		$sql2= "SELECT * FROM `usr` WHERE `uuid` = '".$_GET["uuid"]."'";
		$result2=mysqli_query($mysqli,$sql2);
		$row=mysqli_fetch_row($result2);
		if($row[0]<1){
			$sql3="INSERT INTO `usr` (`no`,`uuid`) VALUES ('',".$_GET["uuid"].")";
			if (!mysqli_query($mysqli,$sql3)) {
				echo "MySQL Error: " . mysqli_error($mysqli);
			} else {
				echo "Success3";
			}
		}else{
			echo "Success2";
		}
	}		
	$mysqli -> close();
}
?>