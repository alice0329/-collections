<?php
	$dbServer = "localhost";
	$dbUserName = "root";
	$dbPassword = "";
	$dbDatabase = "bumpdb";
	function cn2db($dbServer, $dbUserName, $dbPassword, $dbDatabase) {
		$mysqli = mysqli_connect($dbServer, $dbUserName, $dbPassword, $dbDatabase);
		mysqli_set_charset($mysqli, "utf8");
		return $mysqli;
	}
?>