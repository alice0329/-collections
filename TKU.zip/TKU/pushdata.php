<meta charset="utf-8">

<?php
include ("mysql.php");
date_default_timezone_set('Asia/Taipei');
$datetime= date("Y/m/d H:i:s");

if (isset($_GET["uuid"])){
	$mysqli = cn2db($dbServer, $dbUserName, $dbPassword, $dbDatabase);
	$sql= "INSERT INTO `logdata` (`no`,`uuid`, `xValue`, `yValue`, `zValue`, `cValue`, `wValue`, `time` , `startTime`) VALUES ('',".$_GET["uuid"].",".$_GET["xValue"].",".$_GET["yValue"].",".$_GET["zValue"].",".$_GET["cValue"].",".$_GET["wValue"].",'".$datetime."','".$_GET["startTime"]."')";
	
	if (!mysqli_query($mysqli,$sql)) {
		echo "MySQL Error: " . mysqli_error($mysqli);
	} else {
		echo "Success";
	}		
	$mysqli -> close();
}
?>