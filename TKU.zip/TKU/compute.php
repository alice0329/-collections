<?php
// 設定文件utf-8編碼
header("Content-Type:text/html; charset=utf-8");
header("Access-Control-Allow-Origin: *");
include ("mysql.php");
date_default_timezone_set('Asia/Taipei');
$datetime= date("Y/m/d H:i:s");
// 加入DB共用常變數
@$id = $_GET["uuid"];
@$starttime = $_GET["starttime"];

if(isset($_GET["uuid"]) && $_GET["uuid"]!="" && isset($_GET["starttime"]) &&$_GET["starttime"]!=""){
	$mysqli = new mysqli('localhost', 'root', '', 'bumpdb');
	$sql = "SELECT * FROM `compute` WHERE `id`='".$_GET['uuid']."' and `starttime` ='".$_GET['starttime']."'";
	$mysqli -> set_charset("utf8");
	$result = $mysqli -> query($sql);
	$outdata = "";
	$count =mysqli_num_rows($result);
	if($count > 0){
		while ($row = mysqli_fetch_row($result)) {
			//$outdata =$outdata . '{"location" : {"lng" : '.$row[0].',"lat" : '.$row[1].'}},';							
		}
		//$outdata =  rtrim($outdata,',');
		//echo '{ "results": ['.$outdata.']}';
	}
	else{
		//computing
		$sql2 = "SELECT `xValue`,`yValue`,`zValue`,`cValue`,`wValue` FROM `logdata` WHERE `uuid`='".$_GET['uuid']."' and `startTime` ='".$_GET['starttime']."'";
		$mysqli -> set_charset("utf8");
		$result2 = $mysqli -> query($sql2);
//		$oriXarray = array();
//		$oriYarray = array();
//		$oriZarray = array();
		$blarray = array();
		$oriCarray = array();
		$oriWarray = array();
		$sumarray = array();
//		echo $sql2;
		while ($row2 = mysqli_fetch_row($result2)) {
//			array_push($oriXarray,$row2[0]);
//			array_push($oriYarray,$row2[1]);
//			array_push($oriZarray,$row2[2]);
			array_push($sumarray,abs($row2[0])+abs($row2[1])+abs($row2[2]));	
			array_push($oriCarray,$row2[3]);						
			array_push($oriWarray,$row2[4]);	
		}
		for($i =0;$i<sizeof($sumarray)-1;$i++){
			array_push($blarray,abs($sumarray[$i+1]-$sumarray[$i]));
		}
//		for($i =0;$i<sizeof($blarray);$i++){
//			echo $blarray[$i].'<br>';
//		}
		$marker_str="";
		for($i =0;$i<sizeof($blarray)-1;$i++){
			if($blarray[$i]>3.5){
				intsql($id,$starttime,$oriCarray[$i+1],$oriWarray[$i+1]);
			}
		}
	}
}
else{
	echo "error";
}
function intsql($id,$starttime,$c,$w){
	$mysqli = new mysqli('localhost','root', '', 'bumpdb');  
	// 檢查連線態狀
	if ($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	}
	// 設定MySQL為utf8編碼
	$mysqli->set_charset("utf8");
	$sql3 = "INSERT INTO `compute`(`id`, `starttime`, `cValue`, `wValue`) VALUES ('$id','$starttime','$c','$w')";
  	$result3 = $mysqli->query($sql3);
}

 ?>